<div>
    <!-- Sidebar backdrop (mobile only) -->
    <div class="fixed inset-0 bg-slate-900 bg-opacity-30 z-40 lg:hidden lg:z-auto transition-opacity duration-200"
        :class="sidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'" aria-hidden="true" x-cloak></div>

    <!-- Sidebar -->
    <div id="sidebar"
        class="flex flex-col absolute z-40 left-0 top-0 lg:static lg:left-auto lg:top-auto lg:translate-x-0 h-screen overflow-y-scroll lg:overflow-y-auto no-scrollbar w-64 lg:w-20 lg:sidebar-expanded:!w-64 2xl:!w-64 shrink-0 bg-slate-800 p-4 transition-all duration-200 ease-in-out"
        :class="sidebarOpen ? 'translate-x-0' : '-translate-x-64'" @click.outside="sidebarOpen = false"
        @keydown.escape.window="sidebarOpen = false" x-cloak="lg">

        <!-- Sidebar header -->
        <div class="flex justify-around items-center  mb-10 pr-3 sm:px-2">
            <!-- Close button -->
            <button class="lg:hidden text-slate-500 hover:text-slate-400" @click.stop="sidebarOpen = !sidebarOpen"
                aria-controls="sidebar" :aria-expanded="sidebarOpen">
                <span class="sr-only">Close sidebar</span>
                <svg class="w-6 h-6 fill-current" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.7 18.7l1.4-1.4L7.8 13H20v-2H7.8l4.3-4.3-1.4-1.4L4 12z" />
                </svg>
            </button>
            <!-- Logo -->
            <a class="block" href="<?php echo e(route('dashboard')); ?>">
                <div class="w-10 h-10 shrink-0 mr-2 sm:mr-3">
                    <img class="rounded-full" src="<?php echo e(asset('images/CBI-logo.png')); ?>" width="50" height="50"
                        alt="Alex Shatov" />
                </div>
                
            </a>
            <p class="text-slate-200 font-semibold">SMARTLAB SRS</p>
        </div>

        <!-- Links -->
        <div class="space-y-8">
            <!-- Pages group -->
            <div>
                <h3 class="text-xs uppercase text-slate-500 font-semibold pl-3">
                    <span class="hidden lg:block lg:sidebar-expanded:hidden 2xl:hidden text-center w-6"
                        aria-hidden="true">•••</span>
                    <span class="lg:hidden lg:sidebar-expanded:block 2xl:block">Halaman</span>
                </h3>

                <ul class="mt-3">
                    
                    <li
                        class="px-3 py-2 rounded-sm mb-0.5 last:mb-0 <?php if(in_array(Request::segment(1), ['dashboard'])): ?><?php echo e('bg-slate-900'); ?><?php endif; ?>">
                        <a class="block text-slate-200 hover:text-white truncate transition duration-150 <?php if(in_array(Request::segment(1), ['dashboard'])): ?><?php echo e('hover:text-slate-200'); ?><?php endif; ?>"
                            href="<?php echo e(route('dashboard')); ?>">
                            <div class="flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" class="shrink-0 h-6 w-6" height="1em"
                                    viewBox="0 0 512 512">
                                    <!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                                    <path
                                        class="fill-current <?php if(in_array(Request::segment(1), ['dashboard'])): ?><?php echo e('text-emerald-500'); ?><?php else: ?><?php echo e('text-slate-600'); ?><?php endif; ?>"
                                        d="M0 96C0 60.7 28.7 32 64 32H448c35.3 0 64 28.7 64 64V416c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V96zm64 64V416H224V160H64zm384 0H288V416H448V160z" />
                                    
                                </svg>
                                
                                <span
                                    class="text-sm font-medium ml-3 lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">Dashboard</span>
                            </div>
                        </a>
                    </li>
                    <!-- Tracking Sampel -->
                    <li class="px-3 py-2 rounded-sm mb-0.5 last:mb-0 <?php if(in_array(Request::segment(1), ['history_sampel', 'input_progress'])): ?><?php echo e('bg-slate-900'); ?><?php endif; ?>"
                        x-data="{ open: <?php echo e(in_array(Request::segment(1), ['history_sampel', 'input_progress']) ? 1 : 0); ?> }">
                        <a class="block text-slate-200 hover:text-white truncate transition duration-150 <?php if(in_array(Request::segment(1), ['history_sampel.index','input_progress.index'])): ?><?php echo e('hover:text-slate-200'); ?><?php endif; ?>"
                            href="#0" @click.prevent="sidebarExpanded ? open = !open : sidebarExpanded = true">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="shrink-0 h-6 w-6" height="1em"
                                        viewBox="0 0 512 512">
                                        <!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                                        <path
                                            class="fill-current <?php if(in_array(Request::segment(1), ['history_sampel', 'input_progress'])): ?><?php echo e('text-emerald-600'); ?><?php else: ?><?php echo e('text-slate-400'); ?><?php endif; ?>"
                                            d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z" />

                                    </svg>
                                    
                                    <span
                                        class="text-sm font-medium ml-3 lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">Tracking
                                        Sampel</span>
                                </div>
                                <!-- Icon -->
                                <div
                                    class="flex shrink-0 ml-2 lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">
                                    <svg class="w-3 h-3 shrink-0 ml-1 fill-current text-slate-400 <?php if(in_array(Request::segment(1), ['history_sampel.index','input_progress.index'])): ?><?php echo e('rotate-180'); ?><?php endif; ?>"
                                        :class="open ? 'rotate-180' : 'rotate-0'" viewBox="0 0 12 12">
                                        <path d="M5.9 11.4L.5 6l1.4-1.4 4 4 4-4L11.3 6z" />
                                    </svg>
                                </div>
                            </div>
                        </a>
                        <div class="lg:hidden lg:sidebar-expanded:block 2xl:block">
                            <ul class="pl-9 mt-1 <?php if(!in_array(Request::segment(1), ['history_sampel.index', 'input_progress.index'])): ?><?php echo e('hidden'); ?><?php endif; ?>"
                                :class="open ? '!block' : 'hidden'">
                                <li class="mb-1 last:mb-0">
                                    <a class="block text-slate-400 hover:text-slate-200 transition duration-150 truncate <?php if(Route::is('input_progress.index')): ?><?php echo e('!text-emerald-500'); ?><?php endif; ?>"
                                        href="<?php echo e(route('input_progress.index')); ?>">
                                        <span
                                            class="text-sm font-medium lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">Input
                                            Progress</span>
                                    </a>
                                </li>
                                <li class="mb-1 last:mb-0">
                                    <a class="block text-slate-400 hover:text-slate-200 transition duration-150 truncate <?php if(Route::is('history_sampel.index')): ?><?php echo e('!text-emerald-500'); ?><?php endif; ?>"
                                        href="<?php echo e(route('history_sampel.index')); ?>">
                                        <span
                                            class="text-sm font-medium lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">History</span>
                                    </a>
                                </li>

                            </ul>
                        </div>
                    </li>
                    
                    <li
                        class="px-3 py-2 rounded-sm mb-0.5 last:mb-0 <?php if(in_array(Request::segment(1), ['inbox'])): ?><?php echo e('bg-slate-900'); ?><?php endif; ?>">
                        <a class="block text-slate-200 hover:text-white truncate transition duration-150 <?php if(in_array(Request::segment(1), ['inbox'])): ?><?php echo e('hover:text-slate-200'); ?><?php endif; ?>"
                            href="#0">
                            <div class="flex items-center">
                                <svg class="shrink-0 h-6 w-6" height="1em" viewBox="0 0 448 512">
                                    <!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                                    <path
                                        class="fill-current <?php if(in_array(Request::segment(1), ['inbox'])): ?><?php echo e('text-indigo-500'); ?><?php else: ?><?php echo e('text-slate-600'); ?><?php endif; ?>"
                                        d="M288 0H160 128C110.3 0 96 14.3 96 32s14.3 32 32 32V196.8c0 11.8-3.3 23.5-9.5 33.5L10.3 406.2C3.6 417.2 0 429.7 0 442.6C0 480.9 31.1 512 69.4 512H378.6c38.3 0 69.4-31.1 69.4-69.4c0-12.8-3.6-25.4-10.3-36.4L329.5 230.4c-6.2-10.1-9.5-21.7-9.5-33.5V64c17.7 0 32-14.3 32-32s-14.3-32-32-32H288zM192 196.8V64h64V196.8c0 23.7 6.6 46.9 19 67.1L309.5 320h-171L173 263.9c12.4-20.2 19-43.4 19-67.1z" />
                                    <path
                                        class="fill-current <?php if(in_array(Request::segment(1), ['inbox'])): ?><?php echo e('text-indigo-300'); ?><?php else: ?><?php echo e('text-slate-400'); ?><?php endif; ?>"
                                        d="M288 0H160 128C110.3 0 96 14.3 96 32s14.3 32 32 32V196.8c0 11.8-3.3 23.5-9.5 33.5L10.3 406.2C3.6 417.2 0 429.7 0 442.6C0 480.9 31.1 512 69.4 512H378.6c38.3 0 69.4-31.1 69.4-69.4c0-12.8-3.6-25.4-10.3-36.4L329.5 230.4c-6.2-10.1-9.5-21.7-9.5-33.5V64c17.7 0 32-14.3 32-32s-14.3-32-32-32H288zM192 196.8V64h64V196.8c0 23.7 6.6 46.9 19 67.1L309.5 320h-171L173 263.9c12.4-20.2 19-43.4 19-67.1z" />
                                </svg>
                                <span
                                    class="text-sm font-medium ml-3 lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">Stok
                                    Bahan Kimia</span>
                            </div>
                        </a>
                    </li>
                    <!-- E-Commerce -->




                    <li
                        class="px-3 py-2 rounded-sm mb-0.5 last:mb-0 <?php if(in_array(Request::segment(1), ['inbox'])): ?><?php echo e('bg-slate-900'); ?><?php endif; ?>">
                        <a class="block text-slate-200 hover:text-white truncate transition duration-150 <?php if(in_array(Request::segment(1), ['inbox'])): ?><?php echo e('hover:text-slate-200'); ?><?php endif; ?>"
                            href="#0">
                            <div class="flex items-center">
                                <svg class="shrink-0 h-6 w-6" viewBox="0 0 24 24">

                                    <path
                                        class="fill-current <?php if(in_array(Request::segment(1), ['inbox'])): ?><?php echo e('text-indigo-300'); ?><?php else: ?><?php echo e('text-slate-400'); ?><?php endif; ?>"
                                        d="m23.72 12 .229.686A.984.984 0 0 1 24 13v8a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1v-8c0-.107.017-.213.051-.314L.28 12H8v4h8v-4H23.72ZM13 0v7h3l-4 5-4-5h3V0h2Z" />
                                </svg>
                                <span
                                    class="text-sm font-medium ml-3 lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">System</span>
                            </div>
                        </a>
                        <div class="lg:hidden lg:sidebar-expanded:block 2xl:block">
                            <ul class="pl-9 mt-1 <?php if(!in_array(Request::segment(1), ['system.index', 'input_progress.index'])): ?><?php echo e('hidden'); ?><?php endif; ?>"
                                :class="open ? '!block' : 'hidden'">
                                <li class="mb-1 last:mb-0">
                                    <a class="block text-slate-400 hover:text-slate-200 transition duration-150 truncate <?php if(Route::is('input_progress.index')): ?><?php echo e('!text-emerald-500'); ?><?php endif; ?>"
                                        href="<?php echo e(route('system.index')); ?>">
                                        <span
                                            class="text-sm font-medium lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">Input
                                            Parameter</span>
                                    </a>
                                </li>

                            </ul>
                        </div>
                    </li>

                </ul>
            </div>

        </div>

    </div>
</div><?php /**PATH /home/grading/project/smartlabv2/resources/views/components/app/sidebar.blade.php ENDPATH**/ ?>