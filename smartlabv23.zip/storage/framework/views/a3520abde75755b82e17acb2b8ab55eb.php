<div>

    <?php echo e($this->table); ?>

</div><?php /**PATH /home/grading/project/smartlabv2/resources/views/livewire/history-kupa.blade.php ENDPATH**/ ?>