<!-- Your confirmation modal HTML here -->
<!-- Example using Bootstrap Modal -->
<div class="modal fade" id="deleteConfirmationModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <!-- Modal content here -->
    <!-- ... -->

    <!-- Confirm button with onclick event -->
    {{-- <button type="button" class="btn btn-danger" onclick="confirmDelete('{{ $id }}')">Confirm Delete</button> --}}
</div>

<script>

</script>