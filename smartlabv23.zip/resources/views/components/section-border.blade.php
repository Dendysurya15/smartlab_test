<div class="hidden sm:block">
    <div class="py-8">
        <div class="border-t border-slate-200 dark:border-slate-700"></div>
    </div>
</div>
