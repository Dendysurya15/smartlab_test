<div>

    {{ $this->table }}
</div>